%{
Knowledge Gradient for Linear Regression 

notation for the following:
K is the number of alternatives
M is the number of time-steps
N is the size of your linear regression model (N<<K, and hopefully N<<M)
K x M stands for a matrix with K rows and M columns

This function takes in
X:      the design matrix for the linear regression model (K x N)
theta_0:prior for the linear regression parameters (N x 1)
MVar:   variance of measurement noise (scalar)
truth:  true values for the means of alternatives (K x 1)
M:      how many measurements will be made (scalar)

C: Prior covariance matrix for theta. If nothing is used, the default parameter is
(X'*X)^-1*MVar (the empirical estimate)

Weigher: This is a scalar between 0 and 1 (default is 1).
If the mesaurements are from a non-stationary distribution, a smaller "Weigher" puts less weight on the previous observations.
Please see pg. 145 of the book (and the paragraph before equation 7.7).

And returns
theta:      Final estimates for the lin. reg. parameters (N x 1)

OC:         Opportunity cost at each iteration (1 x M)
choices:    Alternatives picked at each iteration (1 x M)

thetaEst:  Estimates at each iteration (N x M)
%}

function [theta,OC,choices,thetaEst]=KGCBLinR(X,theta_0,MVar,truth,M,C,Weigher)

if nargin<=5
    C=diag(diag((X'*X)^-1))*MVar; %assumes independence between terms
end

if nargin<=6
    Weigher=1;
end

theta=theta_0;

OC=[];
choices=[];
thetaEst=[];

%Use KG and Measure M times

for n=1:M
    %Choose using KG
    choice=KGCBLin(theta,C,X,MVar);
    
    %Observe the choice
    observation=truth(choice)+randn(1)*sqrt(MVar);
    
    %Few things for the recursive updating eq.
    errorU=observation-theta'*X(choice,:)';
    gammaU=Weigher*(MVar)+X(choice,:)*C*X(choice,:)';
    
    %Update parameters
    theta=theta+(errorU./gammaU)*C*X(choice,:)';
    C=1./Weigher*(C-(1./gammaU)*C*X(choice,:)'*X(choice,:)*C);
    
    %pick the best one to compare OC
    [max_est, max_choice]=max(X*theta);

    %calculate the opportunity cost
    o_cost=max(truth)-truth(max_choice);
    
    OC=[OC,o_cost]; %update the OC matrix
    choices=[choices, choice]; %update the choice matrix
    
    if nargout>3
        thetaEst=[thetaEst,theta];
    end
    
      
end

end

%X matrix for alternatives (M,K)
%Theta belief about parameters (K,1)
%C covariance for Theta (K,K)
%MVar is a scalar for measurement variance

function [bestX,KGVal,maxKG]=KGCBLin(theta,C,X,MVar)

[K, N]=size(X);

mu=X*theta;
B=X*C;

KGVal=[];

for i=1:K
    Sigma=B*(X(i,:)');
    b=Sigma./sqrt(MVar+Sigma(i));
    KGVal=[KGVal; LogEmaxAffine(mu,b)];
end

[maxKG, bestX]=max(KGVal);

end
