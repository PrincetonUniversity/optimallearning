%{
Knowledge Gradient with Correlated Beliefs (KGCB)

notation for the following:
K is the number of alternatives.
M is the number of time-steps
K x M stands for a matrix with K rows and M columns

This function takes in
mu:     true values for the mean (K x 1)
mu_0:   prior for the mean (K x 1)
beta_W: measurement precision (1/lambda(x)) (K x 1)
covM:   initial covariance matrix (K,K)
M:      how many measurements will be made (scalar)


And returns
mu_est:     Final estimates for the means (K x 1)

OC:         Opportunity cost at each iteration (1 x M)
choices:    Alternatives picked at each iteration (1 x M)
mu_estALL:  Estimates at each iteration (K x M)
%}

function [mu_est, OC, choices, mu_estALL]=kgcb(mu,mu_0,beta_W,covM,M)

K=length(mu_0); %number of available choices

mu_est=mu_0;

OC=[];
choices=[];
mu_estALL=[];

for k=1:M %try the kgcb for M number of times

    %Plogy is the log values of KG for alternatives
    Plogy=[];
    
    for iter1=1:K
        a=mu_est';
        b=covM(iter1,:)/sqrt(1/beta_W(iter1) + covM(iter1,iter1));
        [Plogy]=[Plogy, LogEmaxAffine(a,b)];
    end
    
    [maxh,x]=max(Plogy);
    
    %max_value is the best estimated value of the KG 
    %x is the argument that produces max_value

    %observe the outcome of the decision
    %W_k=mu_k+Z*SigmaW_k where SigmaW is standard deviation of the
    %error for each observation
    W_k=mu(x)+randn(1)*1./sqrt(beta_W(x));

    e_x=zeros(K,1);
    e_x(x)=1;
    
    %updating equations for Normal-Normal model with covariance
    addscalar = (W_k - mu_est(x))/(1/beta_W(x) + covM(x,x));
    mu_est=mu_est + addscalar*covM*e_x;
    covM = covM - (covM*e_x*e_x'*covM)/((1/beta_W(x)) + covM(x,x));
    
    %pick the best one to compare OC
    [max_est, max_choice]=max(mu_est);

    %calculate the opportunity cost
    o_cost=max(mu)-mu(max_choice);
    
    OC=[OC,o_cost]; %update the OC matrix
    choices=[choices, x]; %update the choice matrix
    
    if nargout>3 %if more than three outputs were asked
        mu_estALL=[mu_estALL,mu_est];
    end
    

end
   
end