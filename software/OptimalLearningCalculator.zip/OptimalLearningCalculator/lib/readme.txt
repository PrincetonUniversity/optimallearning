User's Manual for the Knowledge Gradient Calculator
Gerald van den Berg

Index

1. Introduction

2. General Use
	a. Basic Setup
	b. Working with the Correlated KG Section
	c. Working with the Independent KG Section
	d. Working with the On-a-Line KG Section
	e. Working with the Learning Game
	f. What does the "Animate" box do?

3. TroubleShooting
	a. What do the message boxes mean?
	b. The program has entered into the Visual Basic Editor. What do I do?

4. What is the Knowledge Gradient?
	a. Basic overview
	b. Implementation
	c. Online vs. Offline

5. Credits



1. Introduction

	Welcome to the Knowledge Gradient Calculator. This interface is designed to give the user access to the 
	knowledge gradient as a tool without requiring coding expertise. The knowledge gradient is a policy used
	in a class of problems known as optimal learning. It attempts to discover what should be measured next given
	what we currently know. There are certain aspects of this problem that will recur throughout the interface, and 
	are worth a brief review here.

	Alternatives:
	The alternatives refer to the set of available choices, which is represented as a series of values in this case. 
	The number of alternatives is usually referred to by M in this calculator
	
	Priors:
	The knowledge gradient is reliant on the Bayesian statistical framework, which requires a prior belief. This prior
	is our guess at what might be good, and can range from a noninformative prior with uniform means and a very large 
	variance to a series of specific values with low levels of uncertainty. It is a necessary part of the calculation, and can be
	set by the user in the correlated, independent, and on-a-line case. The on-a-line case has a special covariance matrix
	which is defined by the bandwidth and variance parameters. The game will give the user a prior to begin with

	Simulation:
	Whenever the calculator makes an observation or implements a policy it is drawing random samples from a truth with a certain 
	measurement error. The user can define this truth and measurement error and watch the policy attempt to find the best alternative. 
	In the correlated and independent sections a random truth can be generated using the priors or one can be entered manually. 
	For the on-a-line case the truth is defined to be a function given by the user. The policy then slowly discovers this function
	 and tries to find its maximum. 
	For the learning game the goal is to discover the truth, which takes the form of a randomly generated function
	
	Updating Equations:
	Bayesian statistics provide us with a series of updating equations with which we can modify our means and variances given
	the measurement (s) we have just made. These calculations are done every time an observation is made or a policy is implemented
	    
	Policies:
	A policy is a rule concerning which alternative to pick next given what we know now. Generally speaking policies fall somewhere 
	between pure exploitation, where we always pick the current best, to pure exploration, where we pick randomly among the alternatives
	The knowledge gradient index (Vkg) is calculated for the user, and the KG policy specifies that we pick the alternative with the highest
	index. 
	The following policies are implemented in the calculator:
		1. Pure Exploitation: Pick the alternative with the highest current value
		2. Pure exploration: Choose randomly among the alternatives
		3. KG Policy: Pick the entry with the highest knowledge gradient index
		4. Interval Estimation: Pick the alternative with the highest index, where the index is given by mu + z alpha/2 * sigma^2
		   It takes z alpha / 2 as a parameter
		5. Gittins: An online policy (that can also be used offline) where we pick the alternative with the highest index, where the
		   index is given by mu + gamma(n) * sigma
		6. Boltzmann: Pick the entry with the highest index, where the index is given by exp(rho*mu_x) / sum( exp( rho*mu_x' ) )
		   It takes rho as a parameter. If rho = 0, then we have pure exploration. As it goes to infinity, we tend towards pure
		   exploration
		7. Epsilon-Greedy Exploration: This policy explores with probability p and exploits with probabilty (1 - p), where p = c / n
		   It takes c as a parameter. The larger c is, the longer it will continue exploring
		8. Mixed-Exploration: This policy explores with probability p and exploits with probabilty (1 - p)
		   It takes p as a parameter
		9. Max-Variance: This policy is similar to pure exploration, but instead of choosing randomly among the alternatives, it picks
		   the alternative with the highest variance
	Note: The parameters for these policies can be edited by hitting the "Edit Parameters" button


2. General Use
	
	a. Basic Setup
		
		Each of these sections is set up in a similar way to make it easy for the user. There are buttons in the top right corner
		for moving within each section. More details are provided below. The radio buttons can be used to access different sections 
		of the calculator.
		In terms of setting up the problem, there is a recommended general procedure:
			1. Choose a number of alternatives by typing a number into the appropriate box on the top-right of the screen
			2. Edit desired parameters by hitting the "Edit Parameters" button
			3. Fill in the prior means in the second column from the right on the first sheet
			4. For the correlated case: Fill in or generate a covariance matrix by hitting the "Edit Covariance" button
			   For the independent case: Fill in a set of standard deviations on the home sheet
			5. Implement a policy or make inidividual measurements on the "Individual Measurements" page
			6. When finished, clear history

	b. Working with the Correlated KG Section
		
		This is the most general purpose section of the calculator, where the covariance is fully user defined.
		The user can select an alternative to measure by going to the individual measurements page.
		The user can also select a policy on the far right and implement it for a desired number of iterations. Note that
		the parameters for the policies can be edited using tyhe "Edit Parameters" button.
		The Correlated KG Section has 6 tabs:
			1. Home - where all the key information is shown and policies are implemented
			2. Individual Measurements - used for making measurements manually
			3. Graphs - Displays various useful graphs of the current belief and the measurement decisions
			4 & 5. Prior and Current Covariance - Displays the prior covariance and the updated covariance
			6. History - Numerically displays the past measurement decisions and beliefs

	c. Working with the Independent KG Section
		
		This section is specifically for the case when each of the alternatives are independent of each other. The 
		equations simplify themselves, although the results will be identical to those in the correlated section when
		a diagonal matrix with the appropriate variances is used.
		The Independent KG Section has 4 tabs:
			1. Home - where all the key information is shown and policies are implemented
			2. Individual Measurements - used for making measurements manually
			3. Graphs - Displays various useful graphs of the current belief and the measurement decisions
			4. History - Numerically displays the past measurement decisions and beliefs

	d. Working with the On-a-Line Section
	
		This section is devoted specifically to the case when our truth is a function. In this case the covariance is a 
		function that is dependent on the bandwidth and variance parameters but is calculated for the user. Entering a 
		desired function is a little bit tricky. You may use all of the available Excel functions, but the variable is 
		y instead of x due to parsing. The graphs in this section are particularly useful in this section as they give a 
		sense of the updating procedure and the manner in which policies make their decisions. 
		The On-a-Line Section has six tabs:
			1. Home - where all the key information is shown and policies are implemented
			2. Individual Measurements - used for making measurements manually
			3. Graphs - Displays various useful graphs of the current belief and the measurement decisions
			4 & 5. Prior and Current Covariance - Displays the prior covariance and the updated covariance
			6. History - Numerically displays the past measurement decisions and beliefs

	e. Working with the Learning Game
		
		This section is designed to allow the user to compete against the knowledge gradient policy and get a sense of 
		the difficulty of the problem. The truth will be hidden from the user, but he/she can choose the number of alternatives,
		the number of measurements, the type of function, a measurement error, and parameters for the random function if appropriate.
		The user may also select a policy to compete for it. In the game the number of iterations is automatically set to the length
		of the game, and the "number of sample paths" box indicates how many different paths will be tried by the code. The more paths
		the more meaningful the result, but a large number of paths can take a longer amount of time. 
		The game has two tabs:
			1. Home - select a policy to compete against the knowledge gradient
			2. Individual Measurements - use this tab to play the learning game as a user
			2. Current Covariance - Displays the covariance matrix (it is provided and updated for the user)
	f. What does the "Animate" box do?

		Often when implementing a policy over many iterations it is hard to see what decisions are made 
		at individual time increments, and it is tricky to see how the belief progresses in between iterations.
		If the animate box is selected, the belief at each time will be displayed along with the observation 
		corresponding to that time period.
		
3. Troubleshooting
	
	a. What do the message boxes mean?
		
		It was the intent of the author to make the message boxes as self-explanatory as possible. However, there
		are some more confusing ones.
			
			1. "Error in Calculations: Symmatrix must be symmetric"
				This means that the given matrix was either not symmetric OR positive semi-definite, 
				both requirements of a covariance matrix. This can happen if data was improperly entered
				in the correlated section. Use the "Check Validity" button in the "Prior Covariance" 
				section to ensure that it is symmetric
			2. "Error in Calculations: '**Java Error Message**' "
				Here '**Java Error Message**' indicates some input unknown to the user. If this should occur, 
				then simply hit clear history to start over and the error should disappear.	

	b. The program has entered into the Visual Basic Editor. What should I do?
		
		Although this should never happen, on major errors the program could enter the editor
		and flash a message box with the name and number of the error and an option to "End" or "Debug". 
		Please choose end, return to the spreadsheet, and hit "Clear History". This should reset the 
		calculator.

4. What is the Knowledge Gradient? 

	a. Basic Overview

		The knowledge gradient attempts to mathematically discover which alternative should be measured next. It does
		this by looking at which measurement is likely to improve our current best outcome. Thus, if one sets up a prior
		in the independent case with uniform standard deviations and measurement errors but different means, then there will
		be a tie between the best and second-best alternative. It is thus also an increasing function of variance, as an 
		alternative which is currently lower but could be higher is an attractive choice. The knowledge gradient gets its 
		name because in a sense it points in the direction of maximal information by taking an expectation of the difference
		between the current mean and the mean after choosing to observe a certain alternative. For more details see Frazier 
		et al., 2008 and Frazier et al., 2009

	b. Implementation

		The VB code underlying this Excel interface calls JAVA code to do its calculations. This code was written jointly 
		by the author and Lawrence Manning while working at CASTLE Lab under Prof. Warren Powell in the summer of 2009. 
		If desired, the jar file in the lib folder accompanying the calculator can be unzipped and the individual can look
		at the underlying code.

	c. Online vs. Offline

		The user may have noticed the online / offline button in the correllated, independent, and on-a-line section. Offline
		learning stipulates that we look purely at what we should measure to learn as much as possible regarding the maximum.
		When learning online, there is a cost associated with each measurement equal to the observed value. There is also a 
		horizon (finite or infinite) and a discount factor. The goal in this setting is not necessarily to find the best, but 
		to maximize the objective function, which is the sum of the discounted observations. KG Policy tends toward exploitation
		much more quickly in this setting, and competes against the Gittins index policy, which is also effective in this class
		off optimal learning problems.

5. Credits
	
Author: Gerald van den Berg
JAVA Code: Lawrence Manning, Gerald van den Berg
Supervisor: Prof. Warren Powell, Princeton University CASTLE LAB
Copyright: This calculator and the accompanying code is the property of the Trustees of Princeton University, 
		and any distributions hereof require prior approval. 



		 

				

		
	




 

